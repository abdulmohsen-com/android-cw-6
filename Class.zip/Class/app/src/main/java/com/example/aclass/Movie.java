package com.example.aclass;

public class Movie {
    private String Title;
    private String MainActors;
    private Double MovieRating;
    private int pgRating;
    private String Genre;

    public Movie(String title, String mainActors, Double movieRating, int pgRating, String genre) {
        Title = title;
        MainActors = mainActors;
        MovieRating = movieRating;
        this.pgRating = pgRating;
        Genre = genre;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getMainActors() {
        return MainActors;
    }

    public void setMainActors(String mainActors) {
        MainActors = mainActors;
    }

    public Double getMovieRating() {
        return MovieRating;
    }

    public void setMovieRating(Double movieRating) {
        MovieRating = movieRating;
    }

    public int getPgRating() {
        return pgRating;
    }

    public void setPgRating(int pgRating) {
        this.pgRating = pgRating;
    }

    public String getGenre() {
        return Genre;
    }

    public void setGenre(String genre) {
        Genre = genre;
    }
}
