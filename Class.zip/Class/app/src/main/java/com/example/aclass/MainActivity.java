package com.example.aclass;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Movie Avengers_Endgame = new Movie("Avengers Endgame", "Robert Downey Jr. Chris Evans. Chris Hemsworth. Chris Pratt",10.0, 13, "Action, Fiction, Adventure" );
        Movie Jurassic_Park = new Movie("Jurassic Park", "Jeff Goblume. Chris Pratt",10.0, 13, "Action, Fiction, Adventure" );
    }


}